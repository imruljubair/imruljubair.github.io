I = imread('cameraman.png');

R = 35;
C = 92;
W = 80;
H = 60;


% A = [ul(1), ul(2)];
% B = [ul(1), ul(2)+W];
% C = [ul(1)+H, ul(2)+W];
% D = [ul(1)+H, ul(2)];
% 
% I(A(1):B(1), A(2):B(2)) = 0;
% I(B(1):C(1), B(2):C(2)) = 0;
% I(C(1):-1: D(1), C(2):-1:D(2)) = 0;
% I(D(1):-1:A(1), D(2):-1:A(2)) = 0;

figure; imshow(I);
figure; imshow(I(R:R+H, C: C+W));

% imshow(I);


