n = 'y'
while n == 'y':
    n = input('enter Y for continue: ')
    print('you entered: ',n)
