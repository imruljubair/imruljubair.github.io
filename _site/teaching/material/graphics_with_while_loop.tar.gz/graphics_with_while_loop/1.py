n = 1
while n < 5:
    print(n)
    n = n+1
