number = int(input("How long you want to show?: "))
i = number
while i >= 0:
  print(i)
  i = i - 1

print("---end---")
