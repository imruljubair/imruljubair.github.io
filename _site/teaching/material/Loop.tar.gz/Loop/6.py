num = int(input("Factorial of : "))
fact=1
while num >0:
       fact=fact*num
       num=num-1
print("Answer: " + str(fact))



