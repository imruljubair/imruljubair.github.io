number = int(input("How long you want to show?: "))
sum = 0
for i in range(0,number+1):
  print("number: "+str(i))
  print("square: "+str(i*i))

print("---end---")
