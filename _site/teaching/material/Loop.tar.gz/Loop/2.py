number = int(input("How long you want to add?: "))
sum = 0
for i in range(0,number+1):
  sum = sum + i

print(sum)
