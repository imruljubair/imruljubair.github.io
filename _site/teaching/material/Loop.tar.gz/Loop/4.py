number = int(input("How long you want to show?: "))
i = 0
while i < number+1:
  print(i)
  i = i + 1

print("---end---")
