Please cite if you need to use this code directly.
