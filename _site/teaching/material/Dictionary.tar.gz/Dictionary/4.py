
# Adding list as values for keys..... (continued)



card = {}
for letter in ["A", "B", "C"]:
   card[letter] = []

for k in card:
   card[k] = [1,2,3,4] # assigning list elemts as values for key

print(card)
