
# Adding list as values for keys.....


card = {}

for letter in ["A", "B", "C", "D", "E"]:
      card[letter] = [] # empty list

print(card)
