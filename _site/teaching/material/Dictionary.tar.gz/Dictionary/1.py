# creating a dictionary:
# and getting value of a key:

# entry is a dictionary:

entry = {'A':1, 'B':2, 'C':3, 'D':4, 'E':5, 'F':6}

x = entry['A'] # accessing value of key 'A'

print(x)
