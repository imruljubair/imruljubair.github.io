# for loops on dictionary

entry = {'Chris':1, 'Katie':2, 'Joanne':3}

for k in entry:
    print(k, entry[k])
