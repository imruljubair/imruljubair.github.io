# List (Basic)

# Example 1.1
even_numbers = [2, 4, 6, 8]
print("Items in even_numbers list: "+str(even_numbers))


# Example 1.2
names = ['Molly', 'Steven', 'Will', 'Alicia']
print("Items in names list: "+str(names))

# Example 1.3
info = ['Alicia', 27, 1550.87]
print("Items in info list: "+str(info));

# Example 1.4
iterate = list(range(5))
print("Items in iterate list: "+str(iterate))


# Example 1.5
repetition = [1,2,3]*3
print("Items in repetition list: "+str(repetition))
