# Indexing



# Example 2

numbers = [99, 100, 101, 102]


for n in numbers:
    print(n)
