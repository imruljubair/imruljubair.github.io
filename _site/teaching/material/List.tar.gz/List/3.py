# Indexing

# Example 3.1

numbers = [99, 100, 101, 102]
print(numbers[0],  numbers[1], numbers[2])

# Example 3.2

index = 0
while index < 4:
    print(numbers[index])
    index = index + 1
