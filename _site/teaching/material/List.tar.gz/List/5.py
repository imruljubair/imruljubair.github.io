# Concating and slicing list
# Example 5.1

list1 = [1,2,3]
list2 = [4,5,6]

list3 = list1 + list2

print(list3)

# Example 5.2

days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Satureday']
mid_days = days[2:5]
print(mid_days)
