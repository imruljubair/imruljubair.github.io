# This program demonstrates a function
# First we define a function named 'message'

def message():
    print('You call me ????')


print('We are going to call "message" function')
message() # function is called

print('function is executed. Goodbye')
