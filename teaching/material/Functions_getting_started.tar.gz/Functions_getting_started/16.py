def main():
   first_name = input('Enter First Name: ')
   last_name = input('Enter Last Name: ')

   print('Reverse: ')
   reverse_name(first_name, last_name)

def reverse_name(first, last):
   print(last, first)


main()
