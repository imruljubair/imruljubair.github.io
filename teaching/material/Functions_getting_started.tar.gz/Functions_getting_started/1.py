# This program demonstrates a function
# First we define a function named 'message'

def message():
    print('Hello')
    print('How are you?')

# Now, call the function

message()
