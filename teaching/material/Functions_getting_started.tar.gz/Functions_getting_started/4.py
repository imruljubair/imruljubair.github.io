# Variables inside the functions

def main():
    get_name()
    print('hello')
    print('welcome')

def get_name():
    name = input('enter your name: ')

main()
