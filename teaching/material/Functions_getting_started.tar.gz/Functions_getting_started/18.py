my_value = 10

def show_value():
   print(my_value)

show_value()
