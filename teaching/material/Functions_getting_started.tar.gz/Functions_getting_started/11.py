# Function with multiple parameter

def anyFunction(day, month):
    print("Day: "+str(day)+" and month: "+str(month))

anyFunction(17, 6)
