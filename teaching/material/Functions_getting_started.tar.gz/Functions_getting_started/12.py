def anyFunction(theParameter):
    return theParameter

val = anyFunction(11)
print("anyFunction() returns ",val)
