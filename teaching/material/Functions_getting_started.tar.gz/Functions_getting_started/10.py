# Function with parameter

def anyFunction(theNumber): # theNumber is parameter of anyFunction()
    print("The number is ", theNumber)


anyFunction(11) # 11 is the argument passed to theNumber of anyFunction()
