def anyFunction(theParameter):
    theParameter = theParameter + 10;
    return theParameter

val = anyFunction(11)
print("anyFunction() returns ",val)
