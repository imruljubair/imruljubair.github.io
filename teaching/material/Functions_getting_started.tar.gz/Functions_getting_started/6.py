# Local variables

def main():
    get_name()
    print('welcome') 

def get_name():
    name = input('enter your name: ')
    print('Hi, ', name) # variable works fine in this function

main()
